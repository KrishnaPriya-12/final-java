import { Plantdto } from './plantdto';

describe('Plantdto', () => {
  it('should create an instance', () => {
    expect(new Plantdto()).toBeTruthy();
  });
});
