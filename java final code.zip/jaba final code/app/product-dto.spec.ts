import { ProductDTO } from './product-dto';

describe('ProductDTO', () => {
  it('should create an instance', () => {
    expect(new ProductDTO()).toBeTruthy();
  });
});
