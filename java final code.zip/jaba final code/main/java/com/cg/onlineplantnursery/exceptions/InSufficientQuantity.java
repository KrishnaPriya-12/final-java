package com.cg.onlineplantnursery.exceptions;

public class InSufficientQuantity extends Exception {
	public InSufficientQuantity() {
		// TODO Auto-generated constructor stub
	}
	
	public InSufficientQuantity(String message) {
		super(message);
	}

}
